/* Created by Tivotal */

var swiper = new Swiper(".slider", {
  grabCursor: true,
  slidesPerView: 2,
  spaceBetween: 30,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
});
